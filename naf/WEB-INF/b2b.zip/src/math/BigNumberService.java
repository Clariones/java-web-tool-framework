package math;

import java.math.BigDecimal;

public class BigNumberService {
	public BigDecimal add(BigDecimal number1, BigDecimal number2)
	{
		//number1
		return number1.add(number2);
	}
}
