package privilege;

public class UserNotFoundException extends EntityNotFoundException {

	public UserNotFoundException(String string) {
		// TODO Auto-generated constructor stub
		super(string);
	}

}
