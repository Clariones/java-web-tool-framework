package organization;

public class OrganizationList {

}
