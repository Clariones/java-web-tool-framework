package com.terapico.caf;

import java.util.Date;

public class DateTime extends Date {
	
}