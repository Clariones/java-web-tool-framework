package com.terapico.caf.baseelement;

public class BeanIndex {
	
}
