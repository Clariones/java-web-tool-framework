package com.terapico.caf.baseelement;

public class HTMLText extends PlainText {

}
