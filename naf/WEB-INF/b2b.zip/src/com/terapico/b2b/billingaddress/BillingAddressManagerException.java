
package com.terapico.b2b.billingaddress;
import com.terapico.b2b.EntityNotFoundException;
public class BillingAddressManagerException extends Exception {

	public BillingAddressManagerException(String string) {
		super(string);
	}

}


