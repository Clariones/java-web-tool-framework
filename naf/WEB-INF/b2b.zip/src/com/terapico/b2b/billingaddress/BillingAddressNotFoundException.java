
package com.terapico.b2b.billingaddress;
import com.terapico.b2b.EntityNotFoundException;
public class BillingAddressNotFoundException extends EntityNotFoundException {

	public BillingAddressNotFoundException(String string) {
		super(string);
	}

}

