
package com.terapico.b2b.billingaddress;
import com.terapico.b2b.EntityNotFoundException;
public class BillingAddressServiceException extends Exception {

	public BillingAddressServiceException(String string) {
		super(string);
	}

}

