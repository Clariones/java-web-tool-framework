package com.terapico.b2b;
public class EntityNotFoundException extends Exception {
	public EntityNotFoundException(String string) {
		super(string);
	}

}


