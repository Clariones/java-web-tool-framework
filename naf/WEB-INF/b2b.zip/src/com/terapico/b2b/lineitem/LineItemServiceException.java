
package com.terapico.b2b.lineitem;
import com.terapico.b2b.EntityNotFoundException;
public class LineItemServiceException extends Exception {

	public LineItemServiceException(String string) {
		super(string);
	}

}

