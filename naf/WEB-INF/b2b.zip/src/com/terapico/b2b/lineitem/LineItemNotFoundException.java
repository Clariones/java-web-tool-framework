
package com.terapico.b2b.lineitem;
import com.terapico.b2b.EntityNotFoundException;
public class LineItemNotFoundException extends EntityNotFoundException {

	public LineItemNotFoundException(String string) {
		super(string);
	}

}

