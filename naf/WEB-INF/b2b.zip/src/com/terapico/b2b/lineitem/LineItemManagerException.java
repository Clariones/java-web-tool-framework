
package com.terapico.b2b.lineitem;
import com.terapico.b2b.EntityNotFoundException;
public class LineItemManagerException extends Exception {

	public LineItemManagerException(String string) {
		super(string);
	}

}


