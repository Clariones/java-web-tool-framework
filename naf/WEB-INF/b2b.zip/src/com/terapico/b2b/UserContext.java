package com.terapico.b2b;

public interface UserContext {

}
