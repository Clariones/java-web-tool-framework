
package com.terapico.b2b.paymentgroup;
import com.terapico.b2b.EntityNotFoundException;
public class PaymentGroupManagerException extends Exception {

	public PaymentGroupManagerException(String string) {
		super(string);
	}

}


