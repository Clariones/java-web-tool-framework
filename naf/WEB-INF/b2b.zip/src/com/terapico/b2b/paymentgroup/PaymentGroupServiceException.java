
package com.terapico.b2b.paymentgroup;
import com.terapico.b2b.EntityNotFoundException;
public class PaymentGroupServiceException extends Exception {

	public PaymentGroupServiceException(String string) {
		super(string);
	}

}

