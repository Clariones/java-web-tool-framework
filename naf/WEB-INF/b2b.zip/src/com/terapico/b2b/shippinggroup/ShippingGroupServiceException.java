
package com.terapico.b2b.shippinggroup;
import com.terapico.b2b.EntityNotFoundException;
public class ShippingGroupServiceException extends Exception {

	public ShippingGroupServiceException(String string) {
		super(string);
	}

}

