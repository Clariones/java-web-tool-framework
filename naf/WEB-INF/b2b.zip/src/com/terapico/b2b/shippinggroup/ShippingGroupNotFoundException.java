
package com.terapico.b2b.shippinggroup;
import com.terapico.b2b.EntityNotFoundException;
public class ShippingGroupNotFoundException extends EntityNotFoundException {

	public ShippingGroupNotFoundException(String string) {
		super(string);
	}

}

