
package com.terapico.b2b.shippinggroup;
import com.terapico.b2b.EntityNotFoundException;
public class ShippingGroupManagerException extends Exception {

	public ShippingGroupManagerException(String string) {
		super(string);
	}

}


