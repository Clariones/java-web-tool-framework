
package com.terapico.b2b.buyercompany;
import com.terapico.b2b.EntityNotFoundException;
public class BuyerCompanyManagerException extends Exception {

	public BuyerCompanyManagerException(String string) {
		super(string);
	}

}


