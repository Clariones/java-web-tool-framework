
package com.terapico.b2b.buyercompany;
import com.terapico.b2b.EntityNotFoundException;
public class BuyerCompanyNotFoundException extends EntityNotFoundException {

	public BuyerCompanyNotFoundException(String string) {
		super(string);
	}

}

