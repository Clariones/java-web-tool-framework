
package com.terapico.b2b.buyercompany;
import com.terapico.b2b.EntityNotFoundException;
public class BuyerCompanyVersionChangedException extends EntityNotFoundException {

	public BuyerCompanyVersionChangedException(String string) {
		super(string);
	}

}
