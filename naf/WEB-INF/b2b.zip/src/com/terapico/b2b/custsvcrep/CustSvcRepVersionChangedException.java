
package com.terapico.b2b.custsvcrep;
import com.terapico.b2b.EntityNotFoundException;
public class CustSvcRepVersionChangedException extends EntityNotFoundException {

	public CustSvcRepVersionChangedException(String string) {
		super(string);
	}

}
