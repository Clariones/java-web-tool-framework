
package com.terapico.b2b.custsvcrep;
import com.terapico.b2b.EntityNotFoundException;
public class CustSvcRepNotFoundException extends EntityNotFoundException {

	public CustSvcRepNotFoundException(String string) {
		super(string);
	}

}

