
package com.terapico.b2b.role;
import com.terapico.b2b.EntityNotFoundException;
public class RoleManagerException extends Exception {

	public RoleManagerException(String string) {
		super(string);
	}

}


