
package com.terapico.b2b.role;
import com.terapico.b2b.EntityNotFoundException;
public class RoleNotFoundException extends EntityNotFoundException {

	public RoleNotFoundException(String string) {
		super(string);
	}

}

