
package com.terapico.b2b.role;
import com.terapico.b2b.EntityNotFoundException;
public class RoleServiceException extends Exception {

	public RoleServiceException(String string) {
		super(string);
	}

}

