
package com.terapico.b2b.employee;
import com.terapico.b2b.EntityNotFoundException;
public class EmployeeManagerException extends Exception {

	public EmployeeManagerException(String string) {
		super(string);
	}

}


