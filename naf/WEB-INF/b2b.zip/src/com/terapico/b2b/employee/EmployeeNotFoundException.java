
package com.terapico.b2b.employee;
import com.terapico.b2b.EntityNotFoundException;
public class EmployeeNotFoundException extends EntityNotFoundException {

	public EmployeeNotFoundException(String string) {
		super(string);
	}

}

