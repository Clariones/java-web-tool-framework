
package com.terapico.b2b.shipment;
import com.terapico.b2b.EntityNotFoundException;
public class ShipmentManagerException extends Exception {

	public ShipmentManagerException(String string) {
		super(string);
	}

}


