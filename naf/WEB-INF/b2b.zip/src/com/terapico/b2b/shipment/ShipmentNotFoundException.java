
package com.terapico.b2b.shipment;
import com.terapico.b2b.EntityNotFoundException;
public class ShipmentNotFoundException extends EntityNotFoundException {

	public ShipmentNotFoundException(String string) {
		super(string);
	}

}

