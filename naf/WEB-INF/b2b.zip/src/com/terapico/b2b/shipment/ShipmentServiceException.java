
package com.terapico.b2b.shipment;
import com.terapico.b2b.EntityNotFoundException;
public class ShipmentServiceException extends Exception {

	public ShipmentServiceException(String string) {
		super(string);
	}

}

