
package com.terapico.b2b.access;
import com.terapico.b2b.EntityNotFoundException;
public class AccessNotFoundException extends EntityNotFoundException {

	public AccessNotFoundException(String string) {
		super(string);
	}

}

