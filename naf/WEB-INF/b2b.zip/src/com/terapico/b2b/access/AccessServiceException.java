
package com.terapico.b2b.access;
import com.terapico.b2b.EntityNotFoundException;
public class AccessServiceException extends Exception {

	public AccessServiceException(String string) {
		super(string);
	}

}

