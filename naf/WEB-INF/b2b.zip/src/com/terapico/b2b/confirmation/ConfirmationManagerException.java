
package com.terapico.b2b.confirmation;
import com.terapico.b2b.EntityNotFoundException;
public class ConfirmationManagerException extends Exception {

	public ConfirmationManagerException(String string) {
		super(string);
	}

}


