
package com.terapico.b2b.confirmation;
import com.terapico.b2b.EntityNotFoundException;
public class ConfirmationNotFoundException extends EntityNotFoundException {

	public ConfirmationNotFoundException(String string) {
		super(string);
	}

}

