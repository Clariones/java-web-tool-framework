
package com.terapico.b2b.confirmation;
import com.terapico.b2b.EntityNotFoundException;
public class ConfirmationServiceException extends Exception {

	public ConfirmationServiceException(String string) {
		super(string);
	}

}

