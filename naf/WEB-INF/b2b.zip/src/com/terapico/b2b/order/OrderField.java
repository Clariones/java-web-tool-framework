package com.terapico.b2b.order;

public enum OrderField {

}
