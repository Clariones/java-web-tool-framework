
package com.terapico.b2b.order;
import com.terapico.b2b.EntityNotFoundException;
public class OrderNotFoundException extends EntityNotFoundException {

	public OrderNotFoundException(String string) {
		super(string);
	}

}

