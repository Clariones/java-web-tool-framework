
package com.terapico.b2b.order;
import com.terapico.b2b.EntityNotFoundException;
public class OrderServiceException extends Exception {

	public OrderServiceException(String string) {
		super(string);
	}

}

