
package com.terapico.b2b.order;
import com.terapico.b2b.EntityNotFoundException;
public class OrderManagerException extends Exception {

	public OrderManagerException(String string) {
		super(string);
	}

}


