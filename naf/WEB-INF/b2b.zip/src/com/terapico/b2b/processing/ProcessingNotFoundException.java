
package com.terapico.b2b.processing;
import com.terapico.b2b.EntityNotFoundException;
public class ProcessingNotFoundException extends EntityNotFoundException {

	public ProcessingNotFoundException(String string) {
		super(string);
	}

}

