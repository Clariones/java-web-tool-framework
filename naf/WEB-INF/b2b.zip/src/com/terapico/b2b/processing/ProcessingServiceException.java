
package com.terapico.b2b.processing;
import com.terapico.b2b.EntityNotFoundException;
public class ProcessingServiceException extends Exception {

	public ProcessingServiceException(String string) {
		super(string);
	}

}

