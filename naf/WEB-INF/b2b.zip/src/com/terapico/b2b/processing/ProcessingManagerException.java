
package com.terapico.b2b.processing;
import com.terapico.b2b.EntityNotFoundException;
public class ProcessingManagerException extends Exception {

	public ProcessingManagerException(String string) {
		super(string);
	}

}


