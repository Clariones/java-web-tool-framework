
package com.terapico.b2b.action;
import com.terapico.b2b.EntityNotFoundException;
public class ActionNotFoundException extends EntityNotFoundException {

	public ActionNotFoundException(String string) {
		super(string);
	}

}

