
package com.terapico.b2b.action;
import com.terapico.b2b.EntityNotFoundException;
public class ActionVersionChangedException extends EntityNotFoundException {

	public ActionVersionChangedException(String string) {
		super(string);
	}

}
