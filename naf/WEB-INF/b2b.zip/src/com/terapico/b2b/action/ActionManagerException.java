
package com.terapico.b2b.action;
import com.terapico.b2b.EntityNotFoundException;
public class ActionManagerException extends Exception {

	public ActionManagerException(String string) {
		super(string);
	}

}










