
package com.terapico.b2b.action;
import com.terapico.b2b.EntityNotFoundException;
public class ActionServiceException extends Exception {

	public ActionServiceException(String string) {
		super(string);
	}

}

