
package com.terapico.b2b.sellercompany;
import com.terapico.b2b.EntityNotFoundException;
public class SellerCompanyNotFoundException extends EntityNotFoundException {

	public SellerCompanyNotFoundException(String string) {
		super(string);
	}

}

