
package com.terapico.b2b.sellercompany;
import com.terapico.b2b.EntityNotFoundException;
public class SellerCompanyManagerException extends Exception {

	public SellerCompanyManagerException(String string) {
		super(string);
	}

}


