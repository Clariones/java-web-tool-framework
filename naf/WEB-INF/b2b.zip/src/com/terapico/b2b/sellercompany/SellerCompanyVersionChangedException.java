
package com.terapico.b2b.sellercompany;
import com.terapico.b2b.EntityNotFoundException;
public class SellerCompanyVersionChangedException extends EntityNotFoundException {

	public SellerCompanyVersionChangedException(String string) {
		super(string);
	}

}
