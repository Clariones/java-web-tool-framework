
package com.terapico.b2b.sellercompany;
import com.terapico.b2b.EntityNotFoundException;
public class SellerCompanyServiceException extends Exception {

	public SellerCompanyServiceException(String string) {
		super(string);
	}

}

