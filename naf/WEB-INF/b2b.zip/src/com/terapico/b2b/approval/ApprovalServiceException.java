
package com.terapico.b2b.approval;
import com.terapico.b2b.EntityNotFoundException;
public class ApprovalServiceException extends Exception {

	public ApprovalServiceException(String string) {
		super(string);
	}

}

