
package com.terapico.b2b.approval;
import com.terapico.b2b.EntityNotFoundException;
public class ApprovalNotFoundException extends EntityNotFoundException {

	public ApprovalNotFoundException(String string) {
		super(string);
	}

}

