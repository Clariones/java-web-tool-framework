
package com.terapico.b2b.approval;
import com.terapico.b2b.EntityNotFoundException;
public class ApprovalManagerException extends Exception {

	public ApprovalManagerException(String string) {
		super(string);
	}

}


