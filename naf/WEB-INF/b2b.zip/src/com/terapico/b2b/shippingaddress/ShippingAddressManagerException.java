
package com.terapico.b2b.shippingaddress;
import com.terapico.b2b.EntityNotFoundException;
public class ShippingAddressManagerException extends Exception {

	public ShippingAddressManagerException(String string) {
		super(string);
	}

}


