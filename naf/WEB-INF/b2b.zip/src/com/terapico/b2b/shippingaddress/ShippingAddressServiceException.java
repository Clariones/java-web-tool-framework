
package com.terapico.b2b.shippingaddress;
import com.terapico.b2b.EntityNotFoundException;
public class ShippingAddressServiceException extends Exception {

	public ShippingAddressServiceException(String string) {
		super(string);
	}

}

