
package com.terapico.b2b.shippingaddress;
import com.terapico.b2b.EntityNotFoundException;
public class ShippingAddressNotFoundException extends EntityNotFoundException {

	public ShippingAddressNotFoundException(String string) {
		super(string);
	}

}

