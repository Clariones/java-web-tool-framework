
package com.terapico.b2b.assignment;
import com.terapico.b2b.EntityNotFoundException;
public class AssignmentManagerException extends Exception {

	public AssignmentManagerException(String string) {
		super(string);
	}

}


