
package com.terapico.b2b.assignment;
import com.terapico.b2b.EntityNotFoundException;
public class AssignmentVersionChangedException extends EntityNotFoundException {

	public AssignmentVersionChangedException(String string) {
		super(string);
	}

}
