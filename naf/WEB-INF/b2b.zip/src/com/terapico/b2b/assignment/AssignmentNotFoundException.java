
package com.terapico.b2b.assignment;
import com.terapico.b2b.EntityNotFoundException;
public class AssignmentNotFoundException extends EntityNotFoundException {

	public AssignmentNotFoundException(String string) {
		super(string);
	}

}

