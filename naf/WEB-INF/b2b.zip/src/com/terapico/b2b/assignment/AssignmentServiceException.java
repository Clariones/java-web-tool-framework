
package com.terapico.b2b.assignment;
import com.terapico.b2b.EntityNotFoundException;
public class AssignmentServiceException extends Exception {

	public AssignmentServiceException(String string) {
		super(string);
	}

}

