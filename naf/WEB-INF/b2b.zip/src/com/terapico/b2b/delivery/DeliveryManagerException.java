
package com.terapico.b2b.delivery;
import com.terapico.b2b.EntityNotFoundException;
public class DeliveryManagerException extends Exception {

	public DeliveryManagerException(String string) {
		super(string);
	}

}


