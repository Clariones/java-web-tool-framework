
package com.terapico.b2b.delivery;
import com.terapico.b2b.EntityNotFoundException;
public class DeliveryNotFoundException extends EntityNotFoundException {

	public DeliveryNotFoundException(String string) {
		super(string);
	}

}

