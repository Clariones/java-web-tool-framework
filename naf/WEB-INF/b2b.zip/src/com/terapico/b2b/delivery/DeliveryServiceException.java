
package com.terapico.b2b.delivery;
import com.terapico.b2b.EntityNotFoundException;
public class DeliveryServiceException extends Exception {

	public DeliveryServiceException(String string) {
		super(string);
	}

}

