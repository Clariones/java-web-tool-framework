package com.terapico.privilege;
public class EntityNotFoundException extends Exception {
	public EntityNotFoundException(String string) {
		super(string);
	}

}


