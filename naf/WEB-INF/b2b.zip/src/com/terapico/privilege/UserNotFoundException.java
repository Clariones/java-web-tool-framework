
package com.terapico.privilege;

public class UserNotFoundException extends EntityNotFoundException {

	public UserNotFoundException(String string) {
		super(string);
	}

}


