
package com.terapico.privilege;

public class AccessNotFoundException extends EntityNotFoundException {

	public AccessNotFoundException(String string) {
		super(string);
	}

}


