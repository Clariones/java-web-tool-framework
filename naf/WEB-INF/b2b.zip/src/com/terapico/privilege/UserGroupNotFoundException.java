
package com.terapico.privilege;

public class UserGroupNotFoundException extends EntityNotFoundException {

	public UserGroupNotFoundException(String string) {
		super(string);
	}

}







