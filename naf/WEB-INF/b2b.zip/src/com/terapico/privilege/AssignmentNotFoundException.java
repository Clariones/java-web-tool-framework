
package com.terapico.privilege;

public class AssignmentNotFoundException extends EntityNotFoundException {

	public AssignmentNotFoundException(String string) {
		super(string);
	}

}


