package test;

public class CalculateResult  {

	private int value;

	public int getValue() {
		return value;
	}

	public void setValue(int i) {
		// TODO Auto-generated method stub
		this.value=i;
		
	}

}
