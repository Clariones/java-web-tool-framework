package test;

public class DoubleResult {


		private double value;

		public double getValue() {
			return value;
		}

		public void setValue(double i) {
			// TODO Auto-generated method stub
			this.value=i;
			
		}

	
}
