package test;

import java.util.Date;

public class CurrentTime extends Date {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
}
